#include <stdio.h>
#include <stdlib.h>



/* Declaraci�n/Prototipo/Firma de funci�n para reservar espacio en memoria

        Tener en cuenta
            - tipo_dato_devuelto (elaborado: float, int, char, void, double, long, etc)
            - Identificador, nomenclatura (var sustantivo, function verbo+objeto)
            - Par�metros de entrada (var p/par�metro)
        Siempre por arriba de la funci�n main.
        ej tipo_dato_dev verboObjeto (parametros de entrada);
        4 posibles:  retorna   recibe
    prototipo 1         x    |    x   > nula
    prototipo 2         x    |    v   > sumidero infinito n
    prototipo 3         v    |    v   > prototipo ideal �!
    prototipo 4         v    |    x   > proceso generaci�n espontanea
    Usamos nombres para las variables y no direcciones de memoria porque cada vez que ejecutemos el programa
    la direccion puede estar ocupada por otra cosa y se utilizara otro slot aleatorio (RAM)
    Cada variable solo tiene VISIBILIDAD/ALCANCE en el contexto en el que fue declarada (funcion)
    Las funciones suelen llamarse desde main pero tambi�n se llaman desde otras funciones
*/

int mostrarEincrementar(int); /*si est� vac�o, por defecto es un entero.
recibe, mues, increm, dev.      permite chequear consistencia por si el prototipo no coincide
                                p.ej mostrarMensaje(4) no coincide con (void)
                                puedo poner una variable y su nombre, o solamente la var*/

int main()
{
    int num;  //esta var y la de mostrarMensaje son distintas
    int incremento;

    printf("Ingrese un numero: ");
    scanf("%d", &num); // 1- pasa de aqui hacia la implementacion (como si estuviera nesteada)

    // Llamada a la funcion
    incremento = mostrarEincrementar(num);  //"num" parametro actual puede ser una variable diferente a la de mostrar
    //4- vuelve aca y continua ejecutando el resto del codigo (en el caso de mostrar no DEVUELVE dato)
    printf("El numero incrementado es: %d", incremento);
    return 0;

}
// 2da instancia: implementaci�n/desarrollo de funci�n
int mostrarEincrementar(int num) // 2- (int num) parametro formal
{
    int retorno;

    printf("El numero ingresado es: %d", num);
    retorno = num++;

    return retorno;
    //3- y de aqui volvemos a main
}

/* Tarea:
    Lo mismo de gen�ricas pero para float y char
    Los 4 prototipos de funciones SUMAR
    Debe ser cada uno un proyecto
*/
