#include <stdio.h>
#include <stdlib.h>
#include "vectores.h"
#define TAM 5

// funcion q devuelva la ctad de numeros pares que hay en el array y una que devuelva la cantidad de nros positivos

// cada vez que use la palabra TAM  se va a reemplazar por el nro 5
//hace que eso se compile como el valor cinco "buscando y reemplazando"
//Diferencia entre const y define https://www.geeksforgeeks.org/diffference-define-const-c/

int main()
{
    //int const T = 5;
    /*
    int vector[TAM] = {}; // para init en 0, = {}
    char caracteres[TAM] = {'a', 'b', 'c', 'd', 'e'};
    int index;
    int indexCh;
    int pares, positivos, max;

    cargarVector(vector, TAM);
    mostrarVector(vector, TAM);
    max = showMax(vector, TAM);
    printf("El valor maximo es: %d.\n", max);
    index = searchValue(vector, TAM, 5);
    if(index == -1)
    {
        printf("No encontrado\n");
    } else {
        printf("Encontrado: el nro se encuentra en el subindice %d\n", index);
    }
    pares = contarPares(vector, TAM);
    positivos = contarPos(vector, TAM);
    printf("La cantidad de pares es de %d.\n", pares);
    printf("La cantidad de positivos es de %d.\n", positivos);

    indexCh = searchChar(caracteres, TAM, 'a');
    if(indexCh == -1)
    {
        printf("Caracter no encontrado\n");
    } else {
        printf("Encontrado: el caracter se encuentra en el subindice %d\n", indexCh);
    }
    */

    int array[TAM]={5,2,20,6,1};
    char arrayCh[TAM]={'n','c','s','v','a'};
    bubbles(array, TAM);
    mostrarVector(array, TAM);
    bubblesCh(arrayCh,TAM);
    mostrarVectorCh (arrayCh, TAM);

    int a = 9;
    int b = 5;
    int c;
    //swap --- 1er parcial burbujeo obligatorio
    c = a;
    a = b;
    b = c;

    return 0;
}





