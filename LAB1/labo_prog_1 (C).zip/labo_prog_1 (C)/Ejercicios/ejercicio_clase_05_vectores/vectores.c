#include <stdio.h>
#include <stdlib.h>
#include "vectores.h"

/* Carga Secuencial */
/** \brief carga vector por orden de subindice
 *
 * \param int array[] recibe array
 * \param int tamanho recibe cantidad de elementos  del mismo
 * \return void
 */
void cargarVector (int array[], int tamanho)
{
    int i = 0;
    // 1 valor para c/ vector
    for(i=0; i<TAM; i++)
    {
        printf("Ingrese valor: ");
        scanf("%d", &array[i]);
    }
}

/** \brief busca si un valor existe en vector x
 *
 * \param int array[] recibe array
 * \param int tamanho recibe cantidad de elementos del mismo
 * \param int valor que buscamos
 * \return int esta o no esta
 */
int searchValue (int array[], int tamanho, int val)
{
    int index = -1; //si termina de iterar y no se cumple, retorna index
    int i = 0;

    for(i=0; i<TAM; i++)
    {
        if(val == array[i])
        {
            index = i;

            break;
        }
    }
    return index;

}

/** \brief busca si un caracter existe en vector x
 *
 * \param char array[] recibe array de caracteres
 * \param int tamanho recibe cantidad de elementos del mismo
 * \param char caracter que buscamos
 * \return int esta o no esta
 */
int searchChar (char array[], int tamanho, char val)
{
    int index = -1;
    int i = 0;

    for(i=0; i<TAM; i++)
    {
        if(val == array[i])
        {
            index = i;
            break;
        }
    }
    return index;
}


/** \brief cuenta la cantidad de pares en vector x
 *
 * \param int vec[] recibe array
 * \param int tamanho recibe cantidad de elementos del mismo
 * \return contPar cantidad de pares
 */
int contarPares (int array[], int tamanho)
{
    int contPar;
    int i;
    for(i=0; i<TAM; i++)
    {
        if(array[i]%2==0)
        {
            contPar++;
        }
    }
    return contPar;
}

/** \brief cuenta la cantidad de positivos en vector x
 *
 * \param int array[] recibe array
 * \param int tamanho recibe cantidad de elementos del mismo
 * \return contPos cantidad de positivos
 */
int contarPos (int array[], int tamanho)
{
    int contPos;
    int i;
    for(i=0; i<TAM; i++)
    {
        if(array[i]>0)
        {
            contPos++;
        }
    }
    return contPos;
}

/** \brief muestra vector x
 *
 * \param int array[] recibe array
 * \param int tamanho recibe cantidad de elementos del mismo
 */
void mostrarVector (int array[], int tamanho)
{
        int i;
        for(i=0; i<TAM; i++)
        {
            printf("%d\n", array[i]);
        // vector[] muestra el valor cargado a ese subindice del vector
        // si desbordamos para out no p�sa nada (muestra basura) pero si es para in...
        }
}

void mostrarVectorCh (char array[], int tamanho)
{
        int i;
        for(i=0; i<TAM; i++)
        {
            printf("%c\n", array[i]);
        // vector[] muestra el valor cargado a ese subindice del vector
        // si desbordamos para out no p�sa nada (muestra basura) pero si es para in...
        }
}
/** \brief busca el numero maximo vector x
 *
 * \param int array[] recibe array
 * \param int tamanho recibe cantidad de elementos del mismo
 * \return max numero maximo del array
 */
int showMax(int array[], int tamanho)
{
    int i;
    int max;
    for(i=0; i<tamanho; i++)
    {
        if((i == 0) || (max < array[i]))
        {
                max = array[i];
        }
    }
    return max;
}

/** \brief cambia el valor de un subindice del vector x
 *
 * \param int array[] recibe array
 */
void modificarValor(int array[])
{
    array[3] = 450;
}

void bubbles(int array[], int tamanho)
{
    int aux;
    int i;
    int j;

    printf("Burbujeo\n");
    for(i=0;i<4;i++) ///////////////BURBUJEO  -- OBLIGATORIO
    {
        for(j=i+1;j<5;j++)
        {
            if(array[i]>array[j]) // criterio de ordenamiento
            {
                aux = array[i];
                array[i] = array[j];
                array[j] = aux;
            }
        }
    }
}

void bubblesCh(char array[], int tamanho)
{
    char aux;
    char i;
    char j;

    printf("Burbujeo\n");
    for(i=0;i<4;i++) ///////////////BURBUJEO  -- OBLIGATORIO
    {
        for(j=i+1;j<5;j++)
        {
            if(array[i]>array[j]) // criterio de ordenamiento
            {
                aux = array[i];
                array[i] = array[j];
                array[j] = aux;
            }
        }
    }
}

 /* INIT 1 VALOR
    for(i=0; i<TAM; i++)
    {
        vector[i] = 0; /// valor para init
    }
    printf("Vector %d\n", vector);
    // sea que se pone &vector, vector o &vector[0], devuelve la misma dir de memoria, val ref.
    // vamos a usar vector porque es la menos redundante.
    //los vectores se pasan por direcci�n de memoria, referencia, porque la dir lo que recibe es
    //pasaje por ref = vector
    //int t -> se pasa por valor

    */
