#include <stdio.h>
#include <stdlib.h>
#ifndef VECTORES_H_INCLUDED
#define VECTORES_H_INCLUDED
#define TAM 5

void cargarVector (int[], int);
void mostrarVector (int[], int);
void mostrarVectorCh (char[], int);

void modificarValor(int[]);
int showMax(int[], int);
int searchValue (int[], int, int);
int searchChar (char[], int, char);
int contarPos (int[], int);
int contarPares (int[], int);
void bubbles(int[], int);
void bubblesCh(char[], int);

#endif // VECTORES_H_INCLUDED
