#include <stdio.h>
#include <stdlib.h>

int main()
{
    /* E N T R A D A S
    por ahora en printf no se usa el &ampersand
    escapes
        \n similar a br
        \a suena el speaker del mother
        \t tabula. mas orden en columnas.
    variables
        int x (en x se guarda la direccion de memoria) = ( entero) 1 5 10 -5 (algo)-- SHOW W/ %d
        float (coma) 1.5 -5.2 (reserva seis dec. por defecto.) -- SHOW W/%f  OR %.Xf which fixes it up
        char  (un solo caracter) 'a' '5' '{'  -reserva 255 bits(8 cifras binario) -- SHOW W/ %c
        %mascara, donde lo pongo aparece la variable en un string
        + no sabe concatenar, solo sumar, se concatena con una coma. printf("numero es ", var);
    int numero1;
    numero1 - 88;
    printf("numero es: ",

        S A L I D A S
        &numero1 muestra la direccion de memoria donde se guard� esa variable
    scanf("%d" &numero1) "desde direcci�n tal &var tenes que ir hasta esta CLASE de variable"
    scanf("%c", &letra);  no lee lo que pasa y sigue de largo con \n ya que es un caracter (enter)
    Se soluciona con:
            un espacio antes de %c
            fflush(stdin) que limpia el buffer de entrada
            getche() / getch()
        */


    int numero1;
    float numero2;
    float suma;
    char letra;

    printf("Ingrese un numero entero: ");
    scanf("%d", &numero1);
    printf("Ingrese un numero con coma: ");
    scanf("%f", &numero2);
    printf("Ingrese una letra ");
    letra = getch();
    //scanf(" %c", &letra);
    suma = numero1 + numero2;
    printf("\nLos numeros son %d y %.2f \nEl resultado de la suma es %.2f \nLa letra es %c", numero1, numero2, suma, letra);

    return 0;
}
