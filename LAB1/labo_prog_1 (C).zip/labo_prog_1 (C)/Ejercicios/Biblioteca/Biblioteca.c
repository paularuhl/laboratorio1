#include <stdio.h>
#include <stdlib.h>
#include "Biblioteca.h"
**nombres
{"Luis", "Fernando", "Adolfo", "Joaquin", "Hugo", "Yolanda", "Sandra", "Elizabeth", "Laura", "Ruben"}
{"Enrique", "Vicente", "Arturo", "Paula", "Ines", "Camila", "Macarena", "Delfina", "Valeria", "Francisco"}
{"Santiago", "Ramiro", "Lautaro", "Julian", "Luciano", "Andrea", "Fabiana", "Elon", "Matthew", "Hannah"}
/**
 * \brief Pide un n�mero al user y brinda el resultado
 * \param mensaje Es el mensaje a ser mostrado
 * \return El n�mero que ingreso el user
 *
 */
float pedirFloat(char mensaje[])
{
    float flotante;
    printf("%s",mensaje);
    scanf("%f",&flotante);
    return flotante;
}


/**
 * \brief Pide un n�mero al user y brinda el resultado
 * \param mensaje Es el mensaje a ser mostrado
 * \return El n�mero que ingreso el user
 *
 */
int pedirInt(char mensaje[])
{
    int entero;
    printf("%s",mensaje);
    scanf("%d",&entero);
    return entero;
}


/**
 * \brief Pide un caracter al user y brinda el resultado
 * \param mensaje Es el mensaje a ser mostrado
 * \return El caracter que ingreso el user
 *
 */
char pedirChar(char mensaje[])
{
    char caracter;
    printf("%s",mensaje);
    fflush(stdin);
    scanf("%c",&caracter);
    return caracter;
}


/**
 * \brief Genera un n�mero aleatorio
 * \param desde N�mero aleatorio m�nimo
 * \param hasta N�mero aleatorio m�ximo
 * \param iniciar Indica si se trata del primer n�mero solicitado 1 indica que si
 * \return retorna el n�mero aleatorio generado
 *
 */
char pedirNumeroAleatorio(int desde , int hasta, int iniciar)
{
    if(iniciar)
        srand (time(NULL));
    return desde + (rand() % (hasta + 1 - desde)) ;
}



///BIBLIO ARITMETICA
/** \brief Muestra nro ingresado previamente, incrementa de a 1
 *
 * \param num int nro entero
 * \return int nro +1
 *
 */
int mostrarEincrementar(int num)
{
    int retorno;

    printf("El numero ingresado es: %d", num);
    retorno = num++;

    return retorno;
    //3- y de aqui volvemos a main
}

/** \brief suma dos valores ingresados anteriormente
 *
 * \param num1, num2 son los numeros a ser sumados
 * \return float -- resultado de la suma
 *
 */
float sumar(float num1, float num2)
{
            float suma;
            suma = num1 + num2;
            return suma;
}


/** \brief realiza una resta entre dos numeros previamente ingresados
 *
 * \param num1, num2 los numeros para la operaci�n
 * \return float -- resultado de la resta
 *
 */
float restar(float num1, float num2)
{
            float resta;
            resta = num1 - num2;
            return resta;
}

/** \brief realiza una division entre dos numeros
 *
 * \param num1 dividendo, num2 divisor.
 * \return float -- resultado de la division
 *
 */
float dividir(float num1, float num2)
{
    float division;
    division = num1 / num2;
    return division;
/* validar div en tp1 (if necessary)
while((flag==0) || (B==0))
                {
                    if(flag==0)
                    {
                    printf("Error! No ingreso un divisor.\n");
                    break;
                    } else {
                    printf("Error! No se puede dividir por cero.\n");
                    break;
                    }
                }

                if((flag!=0) && (B!=0))
                {
                    division = dividir(A, B);
                    printf("El resultado de %.2f dividido por %.2f es %.2f.\n", A, B, division);
                }
*/
}


/** \brief realiza una multiplicacion entre dos numeros
 *
 * \param num1, num2 factores
 * \return float -- resultado multiplicacion
 *
 */
float multiplicar(float num1, float num2)
{
            float producto;
            producto = num1 * num2;
            return producto;
}

/** \brief realiza una multiplicacion entre dos numeros
 *
 * \param x -- valor para calcular factorial
 * \return float -- resultado factorial de x
 *
 */
float factorial(float x)
{

    if (x < 0)
    {
        printf("Oops! Los numeros negativos no tienen factorial\n");
    }
    else if (x == 0)
    {
        printf("\nEl factorial de 0 es por definici�n 1.\n");
    }
    else
    {
        for(i = 1; i <= x; i++)
        {
            factorial = factorial * i;

        }
        printf("El factorial de %.2f es %.2lf.\n", x, factorial);
    }
}













///VERIF TIPO DE CADENA DE DATOS

/**
 * \brief Verifica si el valor recibido es num�rico
 * \param cadena Array con la cadena a ser analizada
 * \return 1 si es n�merico y 0 si no lo es
 *
 */
int esNumerico(char cadena[])
{
   int i=0;
   while(cadena[i] != '\0')
   {
       if(cadena[i] < '0' || cadena[i] > '9')
           return 0;
       i++;
   }
   return 1;
}

/**
 * \brief Verifica si el valor recibido contiene solo letras
 * \param cadena Array con la cadena a ser analizada
 * \return 1 si contiene solo ' ' y letras y 0 si no lo es
 *
 */
int esSoloLetras(char cadena[])
{
   int i=0;
   while(cadena[i] != '\0')
   {
       if((cadena[i] != ' ') && (cadena[i] < 'a' || cadena[i] > 'z') && (cadena[i] < 'A' || cadena[i] > 'Z'))
           return 0;
       i++;
   }
   return 1;
}


/**
 * \brief Verifica si el valor recibido contiene solo letras y n�meros
 * \param cadena Array con la cadena a ser analizada
 * \return 1 si contiene solo espacio o letras y n�meros, y 0 si no lo es
 *
 */
int esAlfaNumerico(char cadena[])
{
   int i=0;
   while(cadena[i] != '\0')
   {
       if((cadena[i] != ' ') && (cadena[i] < 'a' || cadena[i] > 'z') && (cadena[i] < 'A' || cadena[i] > 'Z') && (cadena[i] < '0' || cadena[i] > '9'))
           return 0;
       i++;
   }
   return 1;
}


/**
 * \brief Verifica si el valor recibido contiene solo n�meros, + y -
 * \param cadena Array con la cadena a ser analizada
 * \return 1 si contiene solo numeros, espacios y un guion.
 *
 */
int esTelefono(char cadena[]) //EJEMPLO A VARIAR
{
   int i=0;
   int contadorGuiones=0;
   while(cadena[i] != '\0')
   {
       if((cadena[i] != ' ') && (cadena[i] != '-') && (cadena[i] < '0' || cadena[i] > '9'))
           return 0;
       if(cadena[i] == '-')
            contadorGuiones++;
       i++;
   }
   if(contadorGuiones==1) // debe tener un guion PERO PUEDE VARIAR
        return 1;

    return 0;
}






///INPUT STRINGS
/**
 * \brief Solicita un texto al usuario y lo devuelve
 * \param mensaje Es el mensaje a ser mostrado
 * \param input Array donde se cargar� el texto ingresado
 * \return void
 */
void getString(char mensaje[],char input[])
{
    printf("%s",mensaje);
    scanf ("%s", input);
}

/**
 * \brief Solicita un texto al usuario y lo devuelve
 * \param mensaje Es el mensaje a ser mostrado
 * \param input Array donde se cargar� el texto ingresado
 * \return 1 si el texto contiene solo letras
 */
int getStringLetras(char mensaje[],char input[])
{
    char aux[256];
    getString(mensaje,aux);
    if(esSoloLetras(aux))
    {
        strcpy(input,aux);
        return 1;
    }
    return 0;
}

/**
 * \brief Solicita un texto num�rico al usuario y lo devuelve
 * \param mensaje Es el mensaje a ser mostrado
 * \param input Array donde se cargar� el texto ingresado
 * \return 1 si el texto contiene solo n�meros
 */
int getStringNumeros(char mensaje[],char input[])
{
    char aux[256];
    getString(mensaje,aux);
    if(esNumerico(aux))
    {
        strcpy(input,aux);
        return 1;
    }
    return 0;
}

/**
 * \brief INIT un array de enteros con el valor recibido
 * \param array Es el array a ser inicializado
 * \param tamanho Indica la logitud del array
 * \param valor Es el valor que sera cargado en cada posicion
 * \return -
 *
 */
void inicializarArrayInt(int array[],int tamanho,int valor)
{
    int i;
    for(i=0;i < tamanho; i++)
    {
        array[i] = valor;
    }
}

/**
 * \brief Inicializa un array de Personas con el valor recibido
 * \param array Es el array a ser inicializado
 * \param cantidadDeElementos Indica la logitud del array
 * \param valor Es el valor que sera cargado en cada posici�n
 * \return void
 *
 */
void inicializarArrayEstructura(EPersona persona[],int tamanho,int valor)
{
    int i;
    for(i=0;i < tamanho; i++)
    {
        persona[i].estado = valor;
    }
}

///STRINGS OTRAS COSAS

/**
 * \brief Busca la primer ocurrencia de un valor en un array de enteros
 * \param array Es el array en el cual buscar
 * \param tamanho Indica la logitud del array
 * \param valor Es el valor que se busca
 * \return Si no hay ocurrencia (-1) y si la hay la posicion de la misma (i)
 *
 */
int buscarPrimerOcurrencia(int array[],int tamanho,int valor)
{
    int i;
    for(i=0;i < tamanho; i++) //si termina de iterar y no se cumple, retorna -1
    {
        if(array[i] == valor)
        {
            return i;
        }
    }
    return -1;
}


/// ESTRUCTURAS
/**
 * \brief Inicializa un array de Personas con el valor recibido
 * \param array Es el array a ser inicializado
 * \param tamanho Indica la logitud del array
 * \param valor Es el valor que sera cargado en cada posici�n
 * \return void
 *
 */
void inicializarArrayEstructura(Persona arrayPersonas[],int tamanho,int valor)
{
    int i;
    for(i=0;i < tamanho; i++)
    {
        arrayPersonas[i].legajo = valor;
    }
}

/**
 * \brief Busca la primer ocurrencia de un valor en un array de Personas
 * \param array Es el array en el cual buscar
 * \param tamanho Indica la logitud del array
 * \param valor Es el valor que se busca
 * \return Si no hay ocurrencia (-1) y si la hay, la posici�n de la misma
 *
 */
int buscarPrimerOcurrenciaESTRUCTURA(Persona arrayPersonas[],int tamanho,int valor)
{
    int i;
    for(i=0;i < tamanho; i++)
    {
        if(arrayPersonas[i].legajo == valor)
        {
            return i;
        }
    }
    return -1;
}
















/* Carga Secuencial */
/** \brief carga vector por orden de subindice pidiendo a user los datos
 *
 * \param int array[] recibe array
 * \param int tamanho recibe cantidad de elementos  del mismo
 * \return void
 */
void cargarVector (int array[], int tamanho)
{
    int i = 0;
    // 1 valor para c/ vector
    for(i=0; i<TAM; i++)
    {
        printf("Ingrese valor: ");
        scanf("%d", array[i]);
    }
}



/** \brief muestra vector x
 *
 * \param int array[] recibe array
 * \param int tamanho recibe cantidad de elementos del mismo
 */
void mostrarArray (int array[], int tamanho)
{
        int i;
        for(i=0; i<TAM; i++)
        {
            printf("%d\n", array[i]);
        // vector[] muestra el valor cargado a ese subindice del vector
        // si desbordamos para out no p�sa nada (muestra basura) pero si es para in...
        }
}


/** \brief busca el numero maximo vector x
 *
 * \param int array[] recibe array
 * \param int tamanho recibe cantidad de elementos del mismo
 * \return max numero maximo del array
 */
int showMax(int array[], int tamanho)
{
    int i;
    int max;
    for(i=0; i<tamanho; i++)
    {
        if((i == 0) || (max < array[i]))
        {
                max = array[i];
        }
    }
    return max;
}


void bubbles(int array[], int tamanho)
{
    int aux;
    int i;
    int j;

    printf("Burbujeo\n");
    for(i=0;i<4;i++) ///////////////BURBUJEO  -- OBLIGATORIO
    {
        for(j=i+1;j<5;j++)
        {
            if(array[i]>array[j]) // criterio de ordenamiento
            {
                aux = array[i];
                array[i] = array[j];
                array[j] = aux;
            }
        }
    }
}

void bubblesCh(char array[], int tamanho)
{
    char aux;
    char i;
    char j;

    printf("Burbujeo\n");
    for(i=0;i<4;i++) ///////////////BURBUJEO  -- OBLIGATORIO
    {
        for(j=i+1;j<5;j++)
        {
            if(array[i]>array[j]) // criterio de ordenamiento
            {
                aux = array[i];
                array[i] = array[j];
                array[j] = aux;
            }
        }
    }
}




/** \brief pide un entero al usuario
 *
 * \param mensaje[] char Mensaje a mostrar
 * \param min max Determinan el rango en el cual puede estar el dato
 * \return devuelve el entero validado
 *
 */
int pedirEntero(char mensaje[], int min, int max)
{
    int numero;
    printf("Ingrese %s", mensaje);  //es para strings
    scanf("%d", &numero);
    numero = validarEntero(numero, min, max, mensaje);
    return numero;
}

/** \brief Valida un entero ingresado dentro de cierto rango y vuelve a pedirlo si es necesario
 *
 * \param dato Es el dato a validar
 * \param min y max Determinan el rango
 * \param mensaje A mostrar
 * \return devuelve el dato validado
 *
 */
int validarEntero (int dato, int min, int max, char mensaje[])
{
    while(dato<min || dato>max)
    {
        printf("Error: Reingrese %s", mensaje);
        scanf("%d", &dato);
    }
    return dato;
}



 ///EXTRAS (EXISTE CONTINUE; huh)
void continuar (void)
{
    printf("\n");
}

/*

/** \brief busca si un caracter existe en vector x
 *
 * \param char array[] recibe array de caracteres
 * \param int tamanho recibe cantidad de elementos del mismo
 * \param char caracter que buscamos
 * \return int esta o no esta

int searchChar (char array[], int tamanho, char val)
{
    int index = -1;
    int i = 0;

    for(i=0; i<TAM; i++)
    {
        if(val == array[i])
        {
            index = i;
            break;
        }
    }
    return index;
}


/** \brief cuenta la cantidad de pares en vector x
 *
 * \param int vec[] recibe array
 * \param int tamanho recibe cantidad de elementos del mismo
 * \return contPar cantidad de pares

int contarPares (int array[], int tamanho)
{
    int contPar;
    int i;
    for(i=0; i<TAM; i++)
    {
        if(array[i]%2==0)
        {
            contPar++;
        }
    }
    return contPar;
}

/** \brief cuenta la cantidad de positivos en vector x
 *
 * \param int array[] recibe array
 * \param int tamanho recibe cantidad de elementos del mismo
 * \return contPos cantidad de positivos

int contarPos (int array[], int tamanho)
{
    int contPos;
    int i;
    for(i=0; i<TAM; i++)
    {
        if(array[i]>0)
        {
            contPos++;
        }
    }
    return contPos;
}

*/
