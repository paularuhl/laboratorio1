#include <stdio.h>
#include <stdlib.h>
#ifndef BIBLIOTECA_H_INCLUDED
#define BIBLIOTECA_H_INCLUDED

//Biblio Headers-Prototipos

int mostrarEincrementar(int);
float pedirNumero (char[]);
float sumar(float, float);
float restar(float, float);
float dividir(float, float);
float multiplicar(float, float);

char continuar(char);



/// VECTORES

void cargarVector (int[], int);
void mostrarVector (int[], int);
void mostrarVectorCh (char[], int);

void modificarValor(int[]);
int showMax(int[], int);
int searchValue (int[], int, int);
int searchChar (char[], int, char);
int contarPos (int[], int);
int contarPares (int[], int);
void bubbles(int[], int);
void bubblesCh(char[], int);

#endif // BIBLIOTECA_H_INCLUDED
