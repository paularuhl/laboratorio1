#include <stdio.h>
#include <stdlib.h>
#include "biblioteca.h"

/* FACTORIAL */
int main()
{
    float A;
    double factorial = 1;
    printf("Ingrese un numero para calcular factorial: ");
    scanf("%f", &A);
    if (A < 0)
                {
                    printf("Oops! Los numeros negativos no tienen factorial\n");
                }
                else if (A == 0)
                {
                    printf("El factorial de 0 es por definici�n 1.\n");
                }
                else
                {
                    for(float i = 1; i <= A; i++)
                    {
                        factorial = factorial * i;

                    }
                    printf("El factorial de %.2f es %.2lf.\n", A, factorial);
                }
}
